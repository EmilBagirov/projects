package com.tac.kulik;

/**
 * Created by kulik on 25.05.15.
 */
public class Figure {
   public void draw() {

   }
}
