package com.tac.kulik;

/**
 * Created by kulik on 22.05.15.
 */
public interface IVector {
    public float distanceFromZ();
}
