package com.tac.kulik;

/**
 * Created by kulik on 25.05.15.
 */
public interface ISquare {
    public float calcSquare();
}
